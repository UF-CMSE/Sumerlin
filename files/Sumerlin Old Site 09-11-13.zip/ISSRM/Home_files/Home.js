// Created by iWeb 3.0.4 local-build-20111220

setTransparentGifURL('Media/transparent.gif');function applyEffects()
{var registry=IWCreateEffectRegistry();registry.registerEffects({stroke_0:new IWStrokeParts([{rect:new IWRect(-1,1,2,124),url:'Home_files/stroke.png'},{rect:new IWRect(-1,-1,2,2),url:'Home_files/stroke_1.png'},{rect:new IWRect(1,-1,126,2),url:'Home_files/stroke_2.png'},{rect:new IWRect(127,-1,2,2),url:'Home_files/stroke_3.png'},{rect:new IWRect(127,1,2,124),url:'Home_files/stroke_4.png'},{rect:new IWRect(127,125,2,2),url:'Home_files/stroke_5.png'},{rect:new IWRect(1,125,126,2),url:'Home_files/stroke_6.png'},{rect:new IWRect(-1,125,2,2),url:'Home_files/stroke_7.png'}],new IWSize(128,126)),stroke_1:new IWStrokeParts([{rect:new IWRect(-5,5,10,154),url:'Home_files/stroke_8.png'},{rect:new IWRect(-5,-5,10,10),url:'Home_files/stroke_9.png'},{rect:new IWRect(5,-5,250,10),url:'Home_files/stroke_10.png'},{rect:new IWRect(255,-5,10,10),url:'Home_files/stroke_11.png'},{rect:new IWRect(255,5,10,154),url:'Home_files/stroke_12.png'},{rect:new IWRect(255,159,10,10),url:'Home_files/stroke_13.png'},{rect:new IWRect(5,159,250,10),url:'Home_files/stroke_14.png'},{rect:new IWRect(-5,159,10,10),url:'Home_files/stroke_15.png'}],new IWSize(260,164))});registry.applyEffects();}
function hostedOnDM()
{return false;}
function onPageLoad()
{loadMozillaCSS('Home_files/HomeMoz.css')
adjustLineHeightIfTooBig('id1');adjustFontSizeIfTooBig('id1');adjustLineHeightIfTooBig('id2');adjustFontSizeIfTooBig('id2');adjustLineHeightIfTooBig('id3');adjustFontSizeIfTooBig('id3');adjustLineHeightIfTooBig('id4');adjustFontSizeIfTooBig('id4');adjustLineHeightIfTooBig('id5');adjustFontSizeIfTooBig('id5');Widget.onload();fixupAllIEPNGBGs();fixAllIEPNGs('Media/transparent.gif');applyEffects()}
function onPageUnload()
{Widget.onunload();}
